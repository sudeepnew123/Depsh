#!/bin/bash
echo "Starting DeepSeek Telegram Bot..."
python3 bot.py
